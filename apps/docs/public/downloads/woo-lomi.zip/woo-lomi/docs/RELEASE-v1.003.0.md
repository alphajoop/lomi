# Release `woo-v1.003.0`

First public GitHub release of **lomi. for WooCommerce** after epic #40 (merchant setup UX + checkout branding).

**Plugin version:** `1.003.0` (`WC_LOMI_VERSION` in `woo-lomi.php`)  
**Monorepo tag:** `woo-v1.003.0` on `lomiafrica/lomi.`  
**Asset:** `woo-lomi.zip` (via [app-release-woo.yml](../../../.github/workflows/app-release-woo.yml))

---

## Pre-release checklist

### Code & version

- [ ] `woo-lomi.php` → `Version: 1.003.0` and `WC_LOMI_VERSION`
- [ ] `package.json` → `"version": "1.003.0"`
- [ ] `readme.txt` → `Stable tag: 1.003.0` + changelog entry
- [ ] PR **chore/bump-plugins-submodule** merged on `lomiafrica/lomi.` (vendored `apps/plugins` + E2E + verify fix)
- [ ] Woo submodule on `lomiafrica/woo` `main` @ merge commit for #40 (`225baed` or later)

### QA (sandbox)

- [ ] `./apps/plugins/scripts/run-plugin-tests.sh --fast` green (with submodules init)
- [ ] Docker Woo E2E: install zip → configure keys → `PAYMENT_SUCCEEDED` webhook → order **Processing**
- [ ] Classic checkout: branding card visible (pay-with image, icons, lock hint)
- [ ] Blocks checkout: same branding card
- [ ] Admin: **Copy URL** webhook works; **Setup health** → API connection OK

### Build (optional local smoke)

```bash
cd apps/plugins/woo
pnpm install --frozen-lockfile
pnpm run build && pnpm run i18n
./scripts/release.sh
unzip -l dist/woo-lomi.zip | head -20   # must contain woo-lomi.php at zip root
```

---

## Publish (maintainers)

Run from **`lomiafrica/lomi.`** `main` after merge:

```bash
git checkout main
git pull origin main
git submodule update --init apps/plugins/woo   # if using vendored layout

# Tag must match plugin version
git tag -a woo-v1.003.0 -m "WooCommerce plugin 1.003.0"
git push origin woo-v1.003.0
```

CI **lomi · release · woo** uploads `woo-lomi.zip` to GitHub Releases.

**Verify after CI:**

- https://github.com/lomiafrica/lomi./releases/tag/woo-v1.003.0
- https://github.com/lomiafrica/lomi./releases/latest/download/woo-lomi.zip → downloads zip (once `latest` points to this release)

**Manual fallback:** Actions → **lomi · release · woo** → **Run workflow** (workflow_dispatch).

---

## GitHub Release notes (copy-paste)

```markdown
## lomi. for WooCommerce 1.003.0

First published `woo-lomi.zip` on GitHub Releases.

### Merchant setup (#40)

- **Setup health** panel: API connection test (`GET /me`), webhook checklist, clearer status labels
- **Webhook URL** with one-click copy (clipboard + fallback)
- **Merchant-friendly API errors** (invalid key, permissions, validation)
- Settings grouped: credentials, checkout, advanced (collapsed by default)

### Checkout branding (#40)

- New **branding card** at payment selection (pay-with image, payment method icons, secure checkout hint)
- **Classic** and **WooCommerce Blocks** checkout supported

### Install

1. Download **woo-lomi.zip** below
2. WordPress → **Plugins → Add New → Upload Plugin**
3. **WooCommerce → Settings → Payments → lomi.** — enable, test mode, API keys + webhook secret
4. Copy webhook URL into [dashboard.lomi.africa](https://dashboard.lomi.africa) (`PAYMENT_SUCCEEDED`, `REFUND_COMPLETED`)

Docs: https://docs.lomi.africa/build/ecommerce-extensions/woocommerce

### Requirements

- WordPress 6.2+, WooCommerce 9.6+, PHP 7.4+
- Store currency XOF, USD, or EUR
```

---

## Post-release

- [ ] Confirm [docs install link](https://docs.lomi.africa/build/ecommerce-extensions/woocommerce) works (`releases/latest/download/woo-lomi.zip`)
- [ ] Notify merchants / support channel
- [ ] Close or update epic #40 / #45 subtasks
- [ ] (Later) WordPress.org / WooCommerce Marketplace listing — not in scope for this tag
